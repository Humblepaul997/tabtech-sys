<?php

$first_name = $_POST['fname'];
$last_name = $_POST['lname'];
$Username = $_POST['username'];
$email_address = $_POST['email'];
$password = $_POST['passowrd'];
$phone_number = $_POST['phonenumber'];
$national_id_number = $_POST['nid'];

if(){
    $host = "localhost";
    $dbUsername = "root";
    $Password = "";
    $dbname = "f_i_d_database";

//create connection
$con = new mysqli($host,$dbUsername,$Password,$dbname);

if(mysqli_connect_error()){
    die('Connect Error('. mysqli_connect_error().')'.mysqli_connect_error());
}else{
    $SELECT = "SELECT email From farmers_info where email = ? Limit 1";
}





}

?>