<?php
   include("user db.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $username = mysqli_real_escape_string($_POST['username']);
      $password = mysqli_real_escape_string($_POST['password']); 
      
      $sql = "SELECT FROM users WHERE username = '$username' and password = '$password'";
      $result = mysqli_query($sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $musername and $password, table row must be 1 row
		
      if($count == 1) {
         session_register("username");
         $_SESSION['login_user'] = $username;
         
         header("location: home.html");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>