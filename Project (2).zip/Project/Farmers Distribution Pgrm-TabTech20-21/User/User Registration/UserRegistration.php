`<?php
session_start();
       
$First_Name = $_POST['First_Name']; 
$Other_Names = $_POST['Other_Names'];
$Last_Name = $_POST['Last_Name'];
$Physical_Address = $_POST['Physical_Address'];
$National_ID_Number = $_POST['National_ID_Number'];
$password_1 = $_POST['password_1'];
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'javatpoint');
    
// REGISTER USER
if (isset($_POST['reg_user']))
    
{
  // receive all input values from the form
  $First_Name = mysqli_real_escape_string($db, $_POST['First_Name']);
  $Other_Names = mysqli_real_escape_string($db, $_POST['Other_Names']);
  $Last_Name = mysqli_real_escape_string($db, $_POST['Last_Name']);
  $Physical_Address = mysqli_real_escape_string($db, $_POST['Physical_Address']);
  $National_ID_Number = mysqli_real_escape_string($db, $_POST['National_ID_Number']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);
}
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($First_Name)) { array_push($errors, "FirstName is required"); }
  if (empty($Last_Name)) { array_push($errors, "LastName is required"); }
  if (empty($Phyiscal_Address)) { array_push($errors, "Address is required"); }
  if (empty($National_ID_Number)) { array_push($errors, "ID Number is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) 
  
  {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $mysqli_query = "SELECT * FROM 'users' First_Name=$First_Name, Other_Names=$Other_Names, Last_Name=$Last_Name, Physical_Address=$Physical_Address, National_ID_Number=$National_ID_Number, password_1=$password_1";
  
  $result = mysqli_query($db, $mysqli_query);
  $users = mysqli_fetch_assoc($result);
  
  if $National_ID_Number = $National_ID_Number('National_ID_Number');
        
    {
      array_push($errors, 'ID already exists' );
    }

  //Finally, register user if there are no errors in the form
    
  if (count($errors) == 0) 
      
  {
  	$password = md5($password_1);//encrypt the password before saving in the database
    
    $mysqli_query = "INSERT INTO 'users' (First_Name, Other_Names, Last_Name, Physical_Address, National_ID_Number, password) VALUES ($First_Name,$Other_Names,$Last_Name,$Physical_Address,$National_ID_Number,$password_1)";
      
  	mysqli_query($db, $mysqli_query);
  	$_SESSION{'National_ID_Number'} = $National_ID_Number;
  	$_SESSION{'success'} = 'You are now logged in';
  	header('DashBoard.html');
  }

?>  